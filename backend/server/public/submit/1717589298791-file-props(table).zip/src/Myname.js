export default function Myname(props){
    return(
        <h3>My name is {props.name}</h3>
    )
}
