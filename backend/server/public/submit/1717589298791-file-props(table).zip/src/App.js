import './App.css';
import Employees from './Employees';
import Song from './Song'
import Myname from './Myname'
// import Mycomp from './Mycomp';

function App() {
  let studentName = "Tanveer Singh"
  return (
    <div className="App">
     <strong>employee</strong>
      <table border={1} align='center' >
        <thead>
          <tr>
            <th>Name</th>
            <th>Department</th>
            <th>Desigination</th>
            <th>Join Year</th>
          </tr>
        </thead>
        <tbody>   
            <Employees name="Tanveer" department="web-development" desigination="employee" joinyear="2024" />
            <Employees name="Ajay" department="app-development" desigination="employee" joinyear="2024" />
            <Employees name="Rithik" department="graphic-designing" desigination="employee" joinyear="2024" />
        
        </tbody>
      </table>
<br/>
      <strong>song</strong>
      <table border={1} align='center'>
        <thead>
            <tr>
              <th>Song name</th>
              <th>Singer name</th>
            </tr>
        </thead>
        <tbody>
            <Song songname="Big-Hearted" singername="Tarsem-Jassar"/>
            <Song songname="Regret" singername="Sidhu-Moose-Wala"/>
        </tbody>
      </table>
      <br/>
      <Myname name={studentName}/>

      {/* <Mycomp/> */}
    </div>
  );
}

export default App;
