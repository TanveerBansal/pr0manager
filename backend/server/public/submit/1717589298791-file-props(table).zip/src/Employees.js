export default function Employees(props) {
    return (
        <tr>
            <td>{props.name}</td>
            <td>{props.department}</td>
            <td>{props.desigination}</td>
            <td>{props.joinyear}</td>
        </tr>
    )
}