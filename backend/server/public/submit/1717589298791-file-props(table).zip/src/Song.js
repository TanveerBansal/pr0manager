export default function Song(props){
    return(
        <tr>
            <td>{props.songname}</td>
            <td>{props.singername}</td>
        </tr>
    )
}